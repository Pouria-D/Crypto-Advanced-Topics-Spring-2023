# Implementation of SHA-256

## A beginner's script to implement the SHA-256 in Python from scratch.

just run the hash.py script in your terminal or command prompt. 
